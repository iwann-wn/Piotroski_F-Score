<?php
session_start();
require_once 'koneksi.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userEmail = $_SESSION['user_email'];
$userNama = $_SESSION['user_nama'];
$userRole = $_SESSION['user_role'];

if (!isset($_GET['id'])) {
    header('Location: all.php');
    exit();
}

// $host = 'localhost';
// $username = 'root';
// $password = '';
// $database = 'saham';

try {
    // $conn = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    // $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $id = $_GET['id'];

    // Ambil kode_saham dari database
    $stmt_kode_saham = $conn->prepare("SELECT kode_saham FROM stock WHERE id = :id");
    $stmt_kode_saham->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt_kode_saham->execute();

    $kode_saham_result = $stmt_kode_saham->fetch(PDO::FETCH_ASSOC);
    $kode_saham = isset($kode_saham_result['kode_saham']) ? $kode_saham_result['kode_saham'] : '';

    $sql = "SELECT stock.*, 
            CASE 
                WHEN stock.skor <= 3 THEN klasifikasi1.kategori
                WHEN stock.skor <= 7 THEN klasifikasi2.kategori
                ELSE klasifikasi3.kategori
            END AS kategori,
            CASE 
                WHEN stock.skor <= 3 THEN klasifikasi1.keterangan
                WHEN stock.skor <= 7 THEN klasifikasi2.keterangan
                ELSE klasifikasi3.keterangan
            END AS keterangan
            FROM stock
            LEFT JOIN klasifikasi AS klasifikasi1 ON stock.skor <= 3 AND klasifikasi1.id = 1
            LEFT JOIN klasifikasi AS klasifikasi2 ON stock.skor > 3 AND stock.skor <= 7 AND klasifikasi2.id = 2
            LEFT JOIN klasifikasi AS klasifikasi3 ON stock.skor > 7 AND klasifikasi3.id = 3
            WHERE stock.id = :id"; // Ubah kondisi WHERE


    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT); // Bind parameter id
    $stmt->execute();

    $stockData = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Tables - SB Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <!-- Navbar Brand-->
        <a class="navbar-brand ps-3 fw-bold" href="index.php">Analisis Saham</a>
        <!-- Sidebar Toggle-->
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i
                class="fas fa-bars"></i></button>
        <!-- Navbar-->

    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">

                        <a class="nav-link" href="index.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>

                        <a class="nav-link" href="upload.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-fw fa-folder"></i></div>
                            Upload
                        </a>

                        <?php if ($userRole === 'admin'): ?>
                            <a class="nav-link" href="admin/users.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                Admin
                            </a>
                        <?php endif; ?>

                        <a class="nav-link" href="logout.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-user fa-fw"></i></div>
                            Logout
                        </a>

                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">Logged in as : </div>
                    <p class="fw-bold">
                        <?php echo $userNama; ?>
                    </p>
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid mb-4 px-4">
                                        
                    <h1 class="mt-4">Detail Saham - 
                        <?php echo htmlspecialchars($kode_saham . 
                        ' - ' . $stockData[0]['tahun']); ?>
                    </h1>

                    <ol class="breadcrumb mb-4">
                    </ol>

                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-chart-bar me-1"></i>
                                    Bar Chart
                                </div>
                                <div class="card-body">
                                    <canvas id="myBarChart" width="100%" height="40"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table me-1"></i>
                            DataTable Saham
                        </div>
                        <div class="card-body">

                            <table id="datatablesSimple">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Kode Saham</th>
                                        <th>Tahun</th>
                                        <th>Net Income</th>
                                        <th>Operating Cashflow</th>
                                        <th>Return on Asset Previous</th>
                                        <th>Return on Asset Now</th>
                                        <th>Quality of Earning</th>
                                        <th>Long Term Debt to Asset Previous</th>
                                        <th>Long Term Debt to Asset Now</th>
                                        <th>Current Ratio Previous</th>
                                        <th>Current Ratio Now</th>
                                        <th>Outstanding Shares Previous</th>
                                        <th>Outstanding Shares Now</th>
                                        <th>Gross Margin Previous</th>
                                        <th>Gross Margin Now</th>
                                        <th>Asset Turnover Previous</th>
                                        <th>Asset Turnover Now</th>
                                        <th>Skor</th>
                                        <th>Kategori</th>
                                        <th>Keterangan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if (!empty($stockData)) {
                                        $count = 1;
                                        foreach ($stockData as $row) {
                                            echo "<tr>";
                                            echo "<td>" . $count++ . "</td>";

                                            echo "<td>" . $row['kode_saham'] . "</td>";
                                            echo "<td>" . $row['tahun'] . "</td>";
                                            echo "<td>" . $row['net_income'] . "</td>";
                                            echo "<td>" . $row['operating_cashflow'] . "</td>";
                                            echo "<td>" . $row['return_on_asset_previous'] . "</td>";
                                            echo "<td>" . $row['return_on_asset_now'] . "</td>";
                                            echo "<td>" . substr($row['quality_of_earning'], -1) . "</td>";
                                            echo "<td>" . $row['long_term_debt_to_asset_previous'] . "</td>";
                                            echo "<td>" . $row['long_term_debt_to_asset_now'] . "</td>";
                                            echo "<td>" . $row['current_ratio_previous'] . "</td>";
                                            echo "<td>" . $row['current_ratio_now'] . "</td>";
                                            echo "<td>" . $row['outstanding_shares_previous'] . "</td>";
                                            echo "<td>" . $row['outstanding_shares_now'] . "</td>";
                                            echo "<td>" . $row['gross_margin_previous'] . "</td>";
                                            echo "<td>" . $row['gross_margin_now'] . "</td>";
                                            echo "<td>" . $row['asset_turnover_previous'] . "</td>";
                                            echo "<td>" . $row['asset_turnover_now'] . "</td>";
                                            echo "<td>" . $row['skor'] . "</td>";
                                            echo "<td>" . $row['kategori'] . "</td>";
                                            echo "<td>" . $row['keterangan'] . "</td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='3'>Data not found</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>

                        </div>
                    </div>

                </div>
            </main>
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted"> </div>
                        <div> Copyright &copy; iwann 2023 </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>

    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js"
        crossorigin="anonymous"></script>
    <script src="js/datatables-simple-demo.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var stockData = <?php echo json_encode($stockData[0]); ?>;
            var labelKeys = [
                'net_income', 'operating_cashflow', 'return_on_asset_previous', 'return_on_asset_now',
                'long_term_debt_to_asset_previous', 'long_term_debt_to_asset_now', 'current_ratio_previous',
                'current_ratio_now', 'outstanding_shares_previous', 'outstanding_shares_now',
                'gross_margin_previous', 'gross_margin_now', 'asset_turnover_previous', 'asset_turnover_now'
            ];

            var labels = [
                'Net Income', 'Operating Cashflow', 'Return On Asset Previous', 'Return On Asset Now',
                'Long Term Debt To Asset Previous', 'Long Term Debt To Asset Now', 'Current Ratio Previous',
                'Current Ratio Now', 'Outstanding Shares Previous', 'Outstanding Shares Now',
                'Gross Margin Previous', 'Gross Margin Now', 'Asset Turnover Previous', 'Asset Turnover Now'
            ];

            var dataValues = labelKeys.map(function (key) {
                return stockData[key];
            });

            // warna hijau ke merah
            var backgroundColors = dataValues.map(function (value) {
                return value > 0 ? 'rgba(0, 255, 0, 0.5)' : 'rgba(255, 0, 0, 0.5)';
            });

            var borderColors = backgroundColors.map(function (color) {
                return color.replace('0.5', '1');
            });

            var data = {
                labels: labels,
                datasets: [{
                    label: stockData['tahun'],
                    backgroundColor: backgroundColors,
                    borderColor: borderColors,
                    borderWidth: 1,
                    data: dataValues
                }]
            };

            var ctx = document.getElementById('myBarChart').getContext('2d');
            var myBarChart = new Chart(ctx, {
                type: 'bar',
                data: data,
                options: {
                    responsive: true,
                    plugins: {
                        legend: { position: 'top' },
                        title: { display: false }
                    },
                    scales: {
                        x: {
                            ticks: {
                                font: {
                                    family: 'Arial',
                                    size: 14,
                                },
                                maxRotation: 90,
                                minRotation: 90
                            }
                        }
                    }
                },
            });
        });

    </script>

</body>

</html>